﻿#TaskPro
#Copyright 2021 Julian H. All rights reserved.
#change directory
$path = $MyInvocation.MyCommand.Path
if (!$path) {$path = $psISE.CurrentFile.Fullpath}
if ($path)  {$path = Split-Path $path -Parent}
Set-Location $path
#hide console

Add-Type -Name Window -Namespace Console -MemberDefinition '
[DllImport("Kernel32.dll")]
public static extern IntPtr GetConsoleWindow();

[DllImport("user32.dll")]
public static extern bool ShowWindow(IntPtr hWnd, Int32 nCmdShow);
'
$consolePtr = [Console.Window]::GetConsoleWindow()
[Console.Window]::ShowWindow($consolePtr, 0)


$VERSION = "2.2.1"

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName PresentationCore,PresentationFramework

$response = Invoke-WebRequest -URI https://jeweled-fox.github.io/taskpro/newest-version.txt
if ($response.StatusCode -eq 200) {
    $serverversion = $response.Content.trim()
    Write-Host ("VERSION RESPONSE: " + ($VERSION -eq $serverversion))
    
    if ($VERSION -ne $serverversion) {
        $upgraderesponse = [System.Windows.MessageBox]::Show("Your version of TaskPro is outdated. Would you like to be taken to the website where you can get an updated version?", "TaskPro", 4, 48)
        if ($upgraderesponse -eq "Yes") {
            Start-Process http://jeweled-fox.github.io/taskpro/
        }
    }
} else {
    [System.Windows.MessageBox]::Show("Could not successfully verify app version. Check your network connection.", "TaskPro", 0, 48)
}

#input box code

Function inputbox([string]$title, [string]$prompt) {

$form = New-Object System.Windows.Forms.Form
$form.Text = $title
$form.Size = New-Object System.Drawing.Size(300,200)
$form.Icon = $PSScriptRoot + "\icon.ico"
$form.StartPosition = 'CenterScreen'
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.FormBorderStyle = "FixedSingle"

$okButton = New-Object System.Windows.Forms.Button
$okButton.Location = New-Object System.Drawing.Point(75,120)
$okButton.Size = New-Object System.Drawing.Size(75,23)
$okButton.Text = 'OK'
$okButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
$form.AcceptButton = $okButton
$form.Controls.Add($okButton)

$cancelButton = New-Object System.Windows.Forms.Button
$cancelButton.Location = New-Object System.Drawing.Point(150,120)
$cancelButton.Size = New-Object System.Drawing.Size(75,23)
$cancelButton.Text = 'Cancel'
$cancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.CancelButton = $cancelButton
$form.Controls.Add($cancelButton)

$label = New-Object System.Windows.Forms.Label
$label.Location = New-Object System.Drawing.Point(10,20)
$label.Size = New-Object System.Drawing.Size(280,60)
$label.Text = $prompt
$form.Controls.Add($label)

$textBox = New-Object System.Windows.Forms.TextBox
$textBox.Location = New-Object System.Drawing.Point(10,80)
$textBox.Size = New-Object System.Drawing.Size(260,20)
$form.Controls.Add($textBox)

$form.Topmost = $true

$form.Add_Shown({$textBox.Select()})
$result = $form.ShowDialog()

if ($result -eq [System.Windows.Forms.DialogResult]::OK)
{
    return $textBox.Text
} else {
    return $false
}
}



$window = New-Object System.Windows.Forms.Form
$window.Size = "500,500"
$window.Text = "TaskPro " + "v" + $VERSION
$window.FormBorderStyle = "FixedSingle"
$window.MaximizeBox = $false
$window.Icon = $PSScriptRoot + "\icon.ico"

#adds task list box
$tasklist = New-Object System.Windows.Forms.TextBox
$tasklist.Multiline = $true
$tasklist.ReadOnly = $true
$tasklist.ScrollBars = "Vertical"
$tasklist.WordWrap = $false
$tasklist.Location = "10,20"
$tasklist.Size = "470,400"
$tasklist.Text = "Click Refresh to see task list."        
$window.Controls.Add($tasklist)

#adds help button
$help = New-Object System.Windows.Forms.Button
$help.Location = "450,430"
$help.Size = "25,25"
$help.tool
$help.Image = [System.Drawing.Image]::FromFile($PSScriptRoot + "\info_20.png")
$window.Controls.Add($help)
#tooltip
$helptooltip = New-Object System.Windows.Forms.ToolTip
$helptooltip.SetToolTip($help, "Help")

#adds control to refresh task list box
$refreshtasklist = New-Object System.Windows.Forms.Button
$refreshtasklist.Location = "10,430"
$refreshtasklist.Size = "60,25"
$refreshtasklist.Text = "Refresh"
$window.Controls.Add($refreshtasklist)
#tooltip
$refreshtasklisttooltip = New-Object System.Windows.Forms.ToolTip
$refreshtasklisttooltip.SetToolTip($refreshtasklist, "Refresh process list")

#adds control to stop a task
$stoptask = New-Object System.Windows.Forms.Button
$stoptask.Location = "75,430"
$stoptask.Size = "60,25"
$stoptask.Text = "Stop task"
$window.Controls.Add($stoptask)
#tooltip
$stoptasktooltip = New-Object System.Windows.Forms.ToolTip
$stoptasktooltip.SetToolTip($stoptask, "Stop process")

#adds control to forcefully kill a task
$killtask = New-Object System.Windows.Forms.Button
$killtask.Location = "140,430"
$killtask.Size = "60,25"
$killtask.Text = "Kill task"
$window.Controls.Add($killtask)
#tooltip
$killtasktooltip = New-Object System.Windows.Forms.ToolTip
$killtasktooltip.SetToolTip($killtask, "Kill process")

#adds control to start a task
$starttask = New-Object System.Windows.Forms.Button
$starttask.Location = "205,430"
$starttask.Size = "60,25"
$starttask.Text = "Start task"
$window.Controls.Add($starttask)
#tooltip
$starttasktooltip = New-Object System.Windows.Forms.ToolTip
$starttasktooltip.SetToolTip($starttask, "Start new process")

#adds control to show extra info about a task
$taskinfo = New-Object System.Windows.Forms.Button
$taskinfo.Location = "270, 430"
$taskinfo.Size = "60,25"
$taskinfo.Text = "Task info"
$window.Controls.Add($taskinfo)
$taskinfotooltip = New-Object System.Windows.Forms.ToolTip
$taskinfotooltip.SetToolTip($taskinfo, "Show extra task info")

#adds function to refresh task list button
$refreshtasklist.Add_Click({
    $refreshtasklist.Enabled = $false
    #header
    $tasklist.Text = ""
    $div = "     |     "
    $tasklist.AppendText("Process name" + $div +  "PID" + $div +  "Session ID" + $div + "Mem usage" + "`r`n")
    $tasklist.AppendText("==========================================================================`r`n")
    $tasklist.AppendText("`r`n")

    $processget = Get-Process

    #process info
    $processget | ForEach-Object {
        $pname = $_.ProcessName
        $ppath = $_.Path
        $id = $_.Id
        $sessionid = $_.SessionId
        $memorysizeKILO = $_.WorkingSet64 / 1000

        $tasklist.AppendText($pname + $div + $id + $div + $sessionid + $div + [math]::Round($memorysizeKILO) + " K" + "`r`n")
        }

        #flushes out any possible spam-clicks
        [System.Windows.Forms.Application]::DoEvents() 
        $refreshtasklist.Enabled = $true
})

#adds function to stop task button
$stoptask.Add_Click({
    $taskchoice = inputbox -title "TaskPro Dialog" -prompt "Input the name or the PID of the process you want to stop."
    if ($taskchoice -ne $false) {
        $process = Get-Process $taskchoice
        if ($process -eq $null) {
            $process = Get-Process -Id $taskchoice
        }
        if ($process -ne $null) {
            $process | ForEach-Object {
                taskkill /im $_.Id
                if ($? -eq $false) {
                    [System.Windows.MessageBox]::Show("Could not kill task.", "TaskPro", 0, 16)
                }   
            }
        } else {
            [System.Windows.MessageBox]::Show("Could not kill task.", "TaskPro", 0, 16)
        }
    }
})

$killtask.Add_Click({
    $taskchoice = inputbox -title "TaskPro Dialog" -prompt "Input the name or the PID of the process you want to forcefully kill."
    if ($taskchoice -ne $false) {
        $process = Get-Process -Name $taskchoice
        if ($process -eq $null) {
            $process = Get-Process -Id $taskchoice
        }
        if ($process -ne $null) {

            $process | ForEach-Object {
                taskkill /f /im $_.Id
                if ($? -eq $false) {
                    [System.Windows.MessageBox]::Show("Could not kill task.", "TaskPro", 0, 16)
                }   
            }
        } else {
            [System.Windows.MessageBox]::Show("Could not kill task.", "TaskPro", 0, 16)
        }
    }
})

$starttask.Add_Click({
    $taskchoice = inputbox -title "TaskPro Dialog" -prompt "Input the file path to the process you want to start."
    if ($taskchoice -ne $false) {
        Start-Process -FilePath $taskchoice
        if ($? -eq $false) {
            [System.Windows.MessageBox]::Show("Could not start task.", "TaskPro", 0, 16)
        }
    }
})

$help.Add_Click({
    $helpwindow = New-Object System.Windows.Forms.Form
    $helpwindow.Text = "TaskPro Help"
    $helpwindow.Size = New-Object System.Drawing.Size(450,600)
    $helpwindow.Icon = $PSScriptRoot + "\icon.ico"
    $helpwindow.StartPosition = 'CenterScreen'
    $helpwindow.MaximizeBox = $false
    $helpwindow.MinimizeBox = $false
    $helpwindow.FormBorderStyle = "FixedSingle"

    $switchbutton = New-Object System.Windows.Forms.Button
    $switchbutton.Text = "View changelog"
    $switchbutton.AutoSize = $true
    $switchbutton.Location = "325,530"
    $helpwindow.Controls.Add($switchbutton)

    $texthandler = New-Object System.Windows.Forms.RichTextBox
    $texthandler.Size = "435,525"
    $texthandler.Multiline = $true
    $texthandler.ReadOnly = $true
    $texthandler.ScrollBars = "Both"
    $texthandler.WordWrap = $true
    $texthandler.Loadfile($PSScriptRoot + "\HELP.rtf")

    $helpwindow.Controls.Add($texthandler)

    $switchbutton.Add_Click({
        if ($switchbutton.Text -eq "View changelog") {
            $texthandler.LoadFile($PSScriptRoot + "\CHANGELOG.rtf")
            $switchbutton.Text = "View help"
        } else {
            $texthandler.LoadFile($PSScriptRoot + "\HELP.rtf")
            $switchbutton.Text = "View changelog"
        }
    })

    $helpwindow.ShowDialog()
})

#adds function to task info button
$taskinfo.Add_Click({
    $taskchoice = inputbox -title "TaskPro Dialog" -prompt "Input the name or PID of the process you want to retrieve."
    if ($taskchoice -ne $false) {
        $process = Get-Process -Name $taskchoice
        if ($process -eq $null) {
            $process = Get-Process -Id $taskchoice
        }
        if ($process -eq $null) {
            [System.Windows.MessageBox]::Show("Process not found.", "TaskPro", 0, 16)
        } else {
            $process | ForEach-Object {
                $formattedmachinename = $_.MachineName
                if ($_.MachineName -eq ".") {
                    $formattedmachinename = $env:computername
                }

                $formattedstring = 
                "Process name: " + $_.Name + 
                "`r`nProcess ID: " + $_.Id + 
                "`r`nPath: " + $_.Path + 
                "`r`nMemory usage: " + $_.WorkingSet64 + " B (" + ($_.WorkingSet64 / 1000) + " KB)" + 
                "`r`nSession ID: " + $_.SessionId +  
                "`r`nMachine name: " + $formattedmachinename + 
                "`r`nMain handle: " + $_.Handle + 
                "`r`nHandle count: " + $_.HandleCount + 
                "`r`nStarted at: " + $_.StartTime

                $procinfoname = ""

                if ($_.MainWindowTitle -eq "") {
                    $procinfoname = $_.Name
                } else {
                    $procinfoname = $_.MainWindowTitle
                }

                [System.Windows.MessageBox]::Show($formattedstring, "Process info for " + $procinfoname, 0, 0)
            }
        }
    }
})

$window.ShowDialog()
$window.Dispose()
Exit